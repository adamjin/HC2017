/**
 * this class represents the result to be printed into the output file
 * */
public class Result {

	
	//this method convert the result info into the string to be written into the output file
	public String toString(){
		StringBuilder str = new StringBuilder();
//		str.append(this.numSlice).append("\\n");
//		for(Slice slice : this.getSlices()){
//			str.append(slice.getCoordinateLeftUp()[0]).append(" ")
//			.append(slice.getCoordinateLeftUp()[1]).append(" ")
//			.append(slice.getCoordinateRightDown()[0]).append(" ")
//			.append(slice.getCoordinateRightDown()[1]).append("\\n");
//		}
		return str.toString();
	}
}
